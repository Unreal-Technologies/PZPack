---Replaced by TransferItemAction
---@deprecated
local TransferItemTypeAction = require("Starlit/client/timedActions/TransferItemAction")
return TransferItemTypeAction