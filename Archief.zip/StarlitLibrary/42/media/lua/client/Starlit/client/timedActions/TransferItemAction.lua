---@deprecated Moved to Starlit/timedActions/TransferItemAction
local TransferItemTypeAction = require("Starlit/timedActions/TransferItemAction")
return TransferItemTypeAction