---@deprecated Replaced by TransferItemAction
local TransferItemTypeAction = require("Starlit/timedActions/TransferItemAction")
return TransferItemTypeAction