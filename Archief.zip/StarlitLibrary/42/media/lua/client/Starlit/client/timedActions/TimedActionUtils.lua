---@deprecated Moved to Starlit/timedActions/TimedActionUtils
local TimedActionUtils = require("Starlit/timedActions/TimedActionUtils")
return TimedActionUtils