CheckMyModTable = CheckMyModTable or {}
--                ModID        WorkshoID
CheckMyModTable["CustomizableBackpacks"] = 2719850086; 