require("ItemTweaker");

TweakItem("Base.ScrapMetal","DisplayName","Metal Scrap");
