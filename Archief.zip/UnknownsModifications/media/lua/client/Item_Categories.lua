require("ItemTweaker_Copy_CC");

--CLEANING
TweakItem("Base.Broom","DisplayCategory","Clean");
